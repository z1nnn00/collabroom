public class RoomStatus {
    private String roomId;
    private String status;

    public RoomStatus(String roomId, String status) {
        this.roomId = roomId;
        this.status = status;
    }

    public String getRoomId() {
        return roomId;
    }

    public String getStatus() {
        return status;
    }
}
