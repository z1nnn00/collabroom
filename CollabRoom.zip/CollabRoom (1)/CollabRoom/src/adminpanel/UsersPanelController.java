package userspanel;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class UsersPanelController implements Initializable {

    @FXML private TableView<UserReservation> userTable;
    @FXML private TableColumn<UserReservation, String> studentNumberCol;
    @FXML private TableColumn<UserReservation, String> reservedByCol;
    @FXML private TableColumn<UserReservation, String> dateSchedCol;
    @FXML private TableColumn<UserReservation, String> timeCol;
    @FXML private TableColumn<UserReservation, Integer> groupSizeCol;
    @FXML private TableColumn<UserReservation, String> statusCol;
    @FXML private TableColumn<UserReservation, String> createdAtCol;
    @FXML private TextField searchField;

    private ObservableList<UserReservation> reservationList = FXCollections.observableArrayList();

    @Override
public void initialize(URL url, ResourceBundle rb) {
    // Set cell value factories
    studentNumberCol.setCellValueFactory(new PropertyValueFactory<>("studentNumber"));
    reservedByCol.setCellValueFactory(new PropertyValueFactory<>("reservedBy"));
    dateSchedCol.setCellValueFactory(new PropertyValueFactory<>("dateSched"));
    timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));
    groupSizeCol.setCellValueFactory(new PropertyValueFactory<>("groupSize"));
    statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
    createdAtCol.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

    // Set preferred widths for each column
    studentNumberCol.setPrefWidth(120);
    reservedByCol.setPrefWidth(150);
    dateSchedCol.setPrefWidth(120);
    timeCol.setPrefWidth(100);
    groupSizeCol.setPrefWidth(100);
    statusCol.setPrefWidth(100);
    createdAtCol.setPrefWidth(160);

    // Allow horizontal scrolling
    userTable.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);

    // Load data
    loadReservations();
    setupSearchFilter();
}


    private void loadReservations() {
        String url = "jdbc:mysql://localhost:3306/collab_room_scheduler";
        String user = "root"; // Adjust if needed
        String password = ""; // Adjust if needed

        String query = "SELECT student_number, fullname, date, time, number_of_members, status, created_at FROM reservationtbl";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String studentNumber = rs.getString("student_number");
                String reservedBy = rs.getString("fullname");
                String dateSched = rs.getString("date");
                String time = rs.getString("time");
                int groupSize = rs.getInt("number_of_members");
                String status = rs.getString("status");
                String createdAt = rs.getString("created_at");

                reservationList.add(new UserReservation(studentNumber, reservedBy, dateSched, time, groupSize, status, createdAt));
            }

            userTable.setItems(reservationList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setupSearchFilter() {
        FilteredList<UserReservation> filteredData = new FilteredList<>(reservationList, p -> true);

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(reservation -> {
                if (newValue == null || newValue.isEmpty()) return true;

                String lowerCaseFilter = newValue.toLowerCase();

                return reservation.getStudentNumber().toLowerCase().contains(lowerCaseFilter)
                    || reservation.getReservedBy().toLowerCase().contains(lowerCaseFilter)
                    || reservation.getDateSched().toLowerCase().contains(lowerCaseFilter)
                    || reservation.getTime().toLowerCase().contains(lowerCaseFilter)
                    || String.valueOf(reservation.getGroupSize()).contains(lowerCaseFilter)
                    || reservation.getStatus().toLowerCase().contains(lowerCaseFilter)
                    || reservation.getCreatedAt().toLowerCase().contains(lowerCaseFilter);
            });
        });

        SortedList<UserReservation> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(userTable.comparatorProperty());
        userTable.setItems(sortedData);
    }
}
