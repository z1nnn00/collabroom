package adminpanel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;

public class RoomsPanelController {

    @FXML private Button btnAvailable001, btnReserved001, btnOccupied001;
    @FXML private Button btnAvailable002, btnReserved002, btnOccupied002;
    @FXML private Button btnAvailable003, btnReserved003, btnOccupied003;
    @FXML private Button btnAvailable004, btnReserved004, btnOccupied004;

    private final String DB_URL = "jdbc:mysql://localhost:3306/collab_room_scheduler";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "";

    @FXML
    private void initialize() {
        // Initialize room statuses and buttons UI
        initRoom("001", btnAvailable001, btnReserved001, btnOccupied001);
        initRoom("002", btnAvailable002, btnReserved002, btnOccupied002);
        initRoom("003", btnAvailable003, btnReserved003, btnOccupied003);
        initRoom("004", btnAvailable004, btnReserved004, btnOccupied004);
    }

    private void initRoom(String roomId,
                          Button availableBtn, Button reservedBtn, Button occupiedBtn) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT status FROM roomstatustbl WHERE room_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, roomId);
            java.sql.ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String status = rs.getString("status").toLowerCase();
                updateRoomStatusUI(status, availableBtn, reservedBtn, occupiedBtn);
            } else {
                // Default if no data found
                updateRoomStatusUI("available", availableBtn, reservedBtn, occupiedBtn);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateRoomStatusUI(String status,
                                    Button availableBtn, Button reservedBtn, Button occupiedBtn) {
        // Reset all buttons to default color
        availableBtn.setTextFill(Color.BLACK);
        reservedBtn.setTextFill(Color.BLACK);
        occupiedBtn.setTextFill(Color.BLACK);

        // Highlight active button
        Color highlight = Color.web("#7178b8");
        switch (status) {
            case "available": availableBtn.setTextFill(highlight); break;
            case "reserved": reservedBtn.setTextFill(highlight); break;
            case "occupied": occupiedBtn.setTextFill(highlight); break;
        }
    }

    private void updateRoomStatus(String roomId, String status,
                                  Button availableBtn, Button reservedBtn, Button occupiedBtn) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "UPDATE roomstatustbl SET status = ? WHERE room_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, status);
            stmt.setString(2, roomId);
            stmt.executeUpdate();

            // Update UI after DB update
            updateRoomStatusUI(status, availableBtn, reservedBtn, occupiedBtn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Button handlers
    @FXML private void handleAvailable001() { updateRoomStatus("001", "available", btnAvailable001, btnReserved001, btnOccupied001); }
    @FXML private void handleReserved001()  { updateRoomStatus("001", "reserved",  btnAvailable001, btnReserved001, btnOccupied001); }
    @FXML private void handleOccupied001()  { updateRoomStatus("001", "occupied",  btnAvailable001, btnReserved001, btnOccupied001); }

    @FXML private void handleAvailable002() { updateRoomStatus("002", "available", btnAvailable002, btnReserved002, btnOccupied002); }
    @FXML private void handleReserved002()  { updateRoomStatus("002", "reserved",  btnAvailable002, btnReserved002, btnOccupied002); }
    @FXML private void handleOccupied002()  { updateRoomStatus("002", "occupied",  btnAvailable002, btnReserved002, btnOccupied002); }

    @FXML private void handleAvailable003() { updateRoomStatus("003", "available", btnAvailable003, btnReserved003, btnOccupied003); }
    @FXML private void handleReserved003()  { updateRoomStatus("003", "reserved",  btnAvailable003, btnReserved003, btnOccupied003); }
    @FXML private void handleOccupied003()  { updateRoomStatus("003", "occupied",  btnAvailable003, btnReserved003, btnOccupied003); }

    @FXML private void handleAvailable004() { updateRoomStatus("004", "available", btnAvailable004, btnReserved004, btnOccupied004); }
    @FXML private void handleReserved004()  { updateRoomStatus("004", "reserved",  btnAvailable004, btnReserved004, btnOccupied004); }
    @FXML private void handleOccupied004()  { updateRoomStatus("004", "occupied",  btnAvailable004, btnReserved004, btnOccupied004); }
}
