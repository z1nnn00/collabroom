package adminpanel;

import java.sql.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class SettingsPanelController {

    @FXML private PasswordField currentPasswordField;
    @FXML private Button enterButton;

    private final String DB_URL = "jdbc:mysql://localhost:3306/collab_room_scheduler";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "";

    @FXML
    private void handleEnterCurrentPassword(ActionEvent event) {
        String inputPassword = currentPasswordField.getText();

        if (inputPassword == null || inputPassword.isEmpty()) {
            showAlert("Please enter your current password.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT password FROM adminacctbl WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "admin");
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String actualPassword = rs.getString("password");
                if (inputPassword.equals(actualPassword)) {
                    try {
                        Parent root = FXMLLoader.load(getClass().getResource("/adminpanel/AccountPanel.fxml"));
                        Stage stage = (Stage) enterButton.getScene().getWindow();
                        stage.setScene(new Scene(root));
                    } catch (Exception e) {
                        showAlert("Failed to load account panel.");
                        e.printStackTrace();
                    }
                } else {
                    showAlert("Incorrect password.");
                }
            } else {
                showAlert("Admin account not found.");
            }

        } catch (SQLException e) {
            showAlert("Database connection error.");
            e.printStackTrace();
        }
    }

    private void showAlert(String message) {
        showAlert(message, Alert.AlertType.ERROR);
    }

    private void showAlert(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
