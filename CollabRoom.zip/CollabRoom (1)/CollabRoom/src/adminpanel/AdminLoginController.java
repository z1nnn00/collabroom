package adminpanel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;

public class AdminLoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private void handleloginbutton (ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        String url = "jdbc:mysql://localhost:3306/collab_room_scheduler";
        String dbUser = "root"; // your MySQL username
        String dbPassword = ""; // your MySQL password, empty if using XAMPP default

        String query = "SELECT * FROM adminacctbl WHERE username = ? AND password = ?";

        try (Connection conn = DriverManager.getConnection(url, dbUser, dbPassword);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Login Successful");
                alert.setHeaderText(null);
                alert.setContentText("Welcome, Admin!");
                alert.showAndWait();

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/adminpanel/AdminDashboard.fxml"));
                Parent root = loader.load();

                Stage newStage = new Stage();
                newStage.setTitle("Admin Dashboard");
                newStage.setScene(new Scene(root));
                newStage.show();

                Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                currentStage.close();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Login Failed");
                alert.setHeaderText(null);
                alert.setContentText("Incorrect username or password.");
                alert.showAndWait();
            }

        } catch (SQLException | IOException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Database or Loading Error");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }
    
    public void handleback(ActionEvent event) {
    try {
        Parent previousRoot = FXMLLoader.load(getClass().getResource("/collabroom/FXMLDocument.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(previousRoot));
        stage.show();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
}

