package adminpanel;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

public class DashboardPanelController implements Initializable {

    @FXML private TableView<Reservation> reservationTable;
    @FXML private TableColumn<Reservation, String> roomIdCol;
    @FXML private TableColumn<Reservation, String> dateCol;
    @FXML private TableColumn<Reservation, String> timeCol;

    @FXML private Text reservedCountText;
    @FXML private Text availableCountText;
    @FXML private Text thisWeekCountText;
    @FXML private Text totalReservationText;

    private final ObservableList<Reservation> reservationList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        roomIdCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));

        loadReservations();
        loadDashboardCounts(); // Load the count values
    }

    private void loadReservations() {
        String url = "jdbc:mysql://localhost:3306/collab_room_scheduler";
        String user = "root";
        String password = "";

        String query = "SELECT room_number, date, time FROM reservationtbl WHERE status = 'confirmed'";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String roomNumber = rs.getString("room_number");
                String date = rs.getString("date");
                String time = rs.getString("time");

                reservationList.add(new Reservation(roomNumber, date, time));
            }

            reservationTable.setItems(reservationList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadDashboardCounts() {
        String url = "jdbc:mysql://localhost:3306/collab_room_scheduler";
        String user = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {

            // Reserved rooms count
            String reservedQuery = "SELECT COUNT(*) FROM roomstatustbl WHERE status = 'reserved'";
            try (PreparedStatement ps = conn.prepareStatement(reservedQuery);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    reservedCountText.setText(rs.getString(1));
                }
            }

            // Available rooms count
            String availableQuery = "SELECT COUNT(*) FROM roomstatustbl WHERE status = 'available'";
            try (PreparedStatement ps = conn.prepareStatement(availableQuery);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    availableCountText.setText(rs.getString(1));
                }
            }

            // This week's reservations (based on created_at timestamp)
            String thisWeekQuery = "SELECT COUNT(*) FROM reservationtbl WHERE YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)";
            try (PreparedStatement ps = conn.prepareStatement(thisWeekQuery);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    thisWeekCountText.setText(rs.getString(1));
                }
            }

            // Total reservations
            String totalQuery = "SELECT COUNT(*) FROM reservationtbl";
            try (PreparedStatement ps = conn.prepareStatement(totalQuery);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    totalReservationText.setText(rs.getString(1));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
