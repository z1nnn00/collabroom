package adminpanel;

import java.sql.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class AccountPanelController {

    @FXML private PasswordField newPasswordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Button confirmButton;

    private final String DB_URL = "jdbc:mysql://localhost:3306/collab_room_scheduler";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "";

    @FXML
    private void handleConfirmPassword(ActionEvent event) {
        String newPassword = newPasswordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        if (newPassword == null || newPassword.isEmpty() || confirmPassword == null || confirmPassword.isEmpty()) {
            showAlert("Please fill in both password fields.");
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            showAlert("Passwords do not match.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String updateQuery = "UPDATE adminacctbl SET password = ? WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, newPassword);
            stmt.setString(2, "admin");
            stmt.executeUpdate();

            showAlert("Password updated successfully!", Alert.AlertType.INFORMATION);

            // ✅ Load AdminDashboard.fxml
            Parent root = FXMLLoader.load(getClass().getResource("/adminpanel/AdminDashboard.fxml"));
            Stage stage = (Stage) confirmButton.getScene().getWindow();
            stage.setScene(new Scene(root));

        } catch (Exception e) {
            showAlert("An error occurred. Please try again.");
            e.printStackTrace();
        }
    }

    private void showAlert(String message) {
        showAlert(message, Alert.AlertType.ERROR);
    }

    private void showAlert(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
