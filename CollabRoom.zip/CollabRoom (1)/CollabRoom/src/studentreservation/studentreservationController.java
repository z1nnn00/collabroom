/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package studentreservation;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 *
 * @author Rayjen Mendoza
 */
public class studentreservationController implements Initializable {
    
    @FXML private TextField fullnameField;
    @FXML private RadioButton studentRadio, adminRadio, facultyRadio, visitorRadio;
    @FXML private ToggleGroup group1;
    @FXML private TextField studentNumberField;
    @FXML private ChoiceBox<String> programChoice, memberCountChoice, timeChoice;
    @FXML private DatePicker datePicker;
    @FXML private TextArea nameOfMembersArea, purposeArea;
    @FXML private Button submitButton;
    
    private Connection connectDB() {
        String url = "jdbc:mysql://localhost:3306/collab_room_scheduler";
        String user = "root"; // Change if you use different MySQL credentials
        String password = "";
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @FXML
    private void handleSubmit() throws IOException {
        String fullname = fullnameField.getText();
        String userType = ((RadioButton) group1.getSelectedToggle()).getText();
        String studentNumber = studentNumberField.getText();
        String program = programChoice.getValue();
        int memberCount = Integer.parseInt(memberCountChoice.getValue());
        String nameOfMembers = nameOfMembersArea.getText();
        LocalDate date = datePicker.getValue();
        String time = timeChoice.getValue();
        String purpose = purposeArea.getText();

        Connection conn = connectDB();
        if (conn != null) {
            try {
                String query = "INSERT INTO reservationtbl (fullname, user_type, student_number, program, number_of_members, name_of_members, date, time, purpose, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, fullname);
                stmt.setString(2, userType);
                stmt.setString(3, studentNumber);
                stmt.setString(4, program);
                stmt.setInt(5, memberCount);
                stmt.setString(6, nameOfMembers);
                stmt.setDate(7, Date.valueOf(date));
                stmt.setString(8, time);
                stmt.setString(9, purpose);
                stmt.setString(10, "on-hold");

                stmt.executeUpdate();
                conn.close();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Reservation Successful");
                alert.setHeaderText(null);
                alert.setContentText("Your reservation has been submitted successfully!");
                alert.showAndWait();
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/roomstatus/reservationstatus.fxml"));
                Parent root = loader.load();

                Stage newStage = new Stage();
                newStage.setTitle("Reservation Status");
                newStage.setScene(new Scene(root));
                newStage.show();

    // Optional: Close the current form
                Stage currentStage = (Stage) submitButton.getScene().getWindow();
                currentStage.close();

                

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        programChoice.getItems().addAll("BS Information Technology", "BS Industrial Engineering", "BS Electronics Engineering", "BS Entrepreneurship", "BS Accountancy", "BS Management System", "BS Information System", "BS Early Childhood Education", "BS Computer Science");
        memberCountChoice.getItems().addAll("5", "6", "7", "8", "9", "10");
        timeChoice.getItems().addAll("8:00AM - 9:00AM", "9:00AM - 10:00AM", "10:00AM - 11:00AM", "11:00AM - 12:00PM", "12:00PM - 1:00PM", "1:00PM - 2:00PM", "2:00PM - 3:00PM", "3:00PM - 4:00PM", "4:00PM - 5:00PM");
    }
    
    @FXML
    private void handleBack(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/collabroom/FXMLDocument.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}